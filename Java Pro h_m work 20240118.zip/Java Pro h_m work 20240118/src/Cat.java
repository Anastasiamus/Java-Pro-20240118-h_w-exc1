public class Cat extends Pet{
    public Cat(String name, String breed, Integer age) {
        super(name, breed, age);
    }

    public void meows(){
        System.out.println(getName() + " мяв-мяв");
    }


    @Override
    public void play(){
        System.out.println(getName() + " играет");
    }
    public void eatMouses(){
        System.out.println(getName() + "eat mauses");
    }
    public void run(){
        System.out.println(getName() + " бежит");
    }

}
