public class Pet {
    private String name;
    private Integer age;
    private String breed;



    public String getName() {
        return name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void play(){
        System.out.println(name + " играет");
    }
    public void run(){
        System.out.println(name + " бежит");
    }

    public Pet(String name,String breed,Integer age){

        this.name = name;
        this.breed = breed;
        this.age = age;
    }



}




 /*1 уровень сложности: 1. У нас в доме живут домашние животные. Попробуйте в этой задаче создать класс Pet
 и записать ему в наследники Cat и Dog. Определите, какие характеристики и поведение ваших питомцев
  общие, а какие проявляются только у конкретного типа.*/
