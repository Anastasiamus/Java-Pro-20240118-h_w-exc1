public class Dog extends Pet{
    public Dog(String name, String breed, Integer age) {
        super(name, breed, age);
    }

    public void barks() {
        System.out.println("  гав-гав");
    }


    public void executesCommands() {
        System.out.println(" FAS");
    }
    @Override
    public void play(){
        System.out.println(getName() + "  играет");
    }
    public void run(){
        System.out.println(getName() + "  бежит");
    }



}
