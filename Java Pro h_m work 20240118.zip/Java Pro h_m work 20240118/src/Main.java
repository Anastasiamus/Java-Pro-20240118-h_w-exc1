public class Main {
    public static void main(String[] args) {
        Cat cat = new Cat("Vasja", "British", 4);
        Cat cat1 = new Cat("Myrsik", "Dvornyaga", 14);

        System.out.println(cat.getName() + cat1.getName());
        System.out.println(cat.getBreed() + cat1.getBreed());
        System.out.println(cat.getAge());

        cat.play();
        cat1.play();

        cat.run();
        cat1.run();

        cat.meows();
        cat1.meows();

        cat.eatMouses();
        cat1.eatMouses();



        Dog dog = new Dog("Grom", "Pit-bul", 2);

        System.out.println(dog.getName());
        System.out.println(dog.getBreed());
        System.out.println(dog.getAge());
        dog.play();
        dog.run();
        dog.barks();
        dog.executesCommands();
    }
}





 /*1 уровень сложности: 1. У нас в доме живут домашние животные. Попробуйте в этой задаче создать класс Pet
         и записать ему в наследники Cat и Dog. Определите, какие характеристики и поведение ваших питомцев
         общие, а какие проявляются только у конкретного типа.*/











